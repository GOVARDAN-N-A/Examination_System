# Examination System Report
This report provides an overview of the Examination System, including details about students, exams, and their performance.

# Students
The following students have registered for the examination:

Student Name: John Doe
Roll Number: 1
Approved: Yes
Status: Attended Exam
Marks: 7

Student Name: Jane Smith
Roll Number: 2
Approved: Yes
Status: Attended Exam
Marks: 5

Student Name: Michael Johnson
Roll Number: 3
Approved: No
Status: Not Attended Exam
Marks: 0

# Exam Questions
The exam consists of the following questions:

# Question 1:

Option 1: Choice A
Option 2: Choice B
Option 3: Choice C
Correct Answer: 1

# Question 2:

Option 1: Choice X
Option 2: Choice Y
Option 3: Choice Z
Correct Answer: 3

# Question 3:

Option 1: Choice P
Option 2: Choice Q
Option 3: Choice R
Correct Answer: 2

# Exam Report
The overall exam report is as follows:

Student Name	Roll Number	Mark	Approved	Exam Attended
John Doe	1	7	Yes	Yes
Jane Smith	2	5	Yes	Yes
Michael Johnson	3	0	No	No

# Conclusion
The Examination System successfully recorded students' data, allowed staff to approve students, created exams, and conducted exams for eligible students. The exam report provides a summary of each student's performance, including marks obtained and exam attendance status.